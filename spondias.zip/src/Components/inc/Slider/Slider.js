import React, { useEffect } from "react";
import image1 from "./slide/slide-1.jpg";
import image2 from "./slide/slide-2.jpg";
import image3 from "./slide/slide-3.jpg";
import AOS from 'aos';
import 'aos/dist/aos.css';
import './Slider.css';

function Slider() {
  useEffect(() => {
    AOS.init();
  }, []);

  return (
    <div className="container-fluid" style={{ backgroundColor: '#29a9e2', paddingTop: '5px', paddingLeft: '0', paddingRight: '0' }}>
      <section id="hero">
        <div
          id="heroCarousel"
          data-bs-interval="4000"
          className="carousel slide carousel-fade"
          data-bs-ride="carousel"
        >
          <div className="carousel-inner">
            <div className="carousel-item aos-init aos-animate" data-aos="fade-up">
              <div className="overlay-1" style={{ backgroundImage: `url(${image1})` }}>
                <div className="carousel-container">
                  <div className="carousel-content animate__animated animate__fadeInUp">
                    <h2 className="animate-charcter animate__animated animate__fadeInUp">Welcome to Spondias</h2>
                    <p className="sub-text animate__animated animate__fadeInUp">Development services with the latest technology</p>
                    <a className="text-center btn text-white animate__animated animate__fadeInUp" style={{ backgroundColor: "#29a9e2", fontFamily: 'Imprima, sans-serif' }} href="contact.php">
                      Let's Connect
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="carousel-item active aos-init aos-animate" data-aos="fade-up">
              <div className="overlay-1" style={{ backgroundImage: `url(${image2})` }}>
                <div className="carousel-container">
                  <div className="carousel-content animate__animated animate__fadeInUp">
                    <h2 className="animate-charcter animate__animated animate__fadeInUp">Best Choice For Your Business</h2>
                    <p className="sub-text animate__animated animate__fadeInUp">
                      Spondias is a company dedicated to personal service, tailoring our expertise in Corporate Training &amp; Project Consulting.
                    </p>
                    <a className="text-center btn text-white animate__animated animate__fadeInUp" style={{ backgroundColor: "#29a9e2", fontFamily: 'Imprima, sans-serif' }} href="contact.php">
                      Let's Connect
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="carousel-item aos-init aos-animate" data-aos="fade-up">
              <div className="overlay-1" style={{ backgroundImage: `url(${image3})` }}>
                <div className="carousel-container">
                  <div className="carousel-content animate__animated animate__fadeInUp">
                    <h2 className="animate-charcter animate__animated animate__fadeInUp">Professional Software Services</h2>
                    <p className="sub-text animate__animated animate__fadeInUp">We Offer a Wide Range of Software Solutions with the latest technologies</p>
                    <a className="text-center btn text-white animate__animated animate__fadeInUp" style={{ backgroundColor: "#29a9e2", fontFamily: 'Imprima, sans-serif' }} href="contact.php">
                      Let's Connect
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <a className="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
            <span className="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
          </a>

          <a className="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
            <span className="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
          </a>
        </div>
      </section>
    </div>
  );
}

export default Slider;
